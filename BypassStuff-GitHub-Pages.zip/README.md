# BypassStuff — GitHub Pages edition

## Publish from an iPhone
1. Create a **public** repository named `YOUR-USERNAME.github.io`.
2. Upload `index.html`, `styles.css`, and `app.js` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose branch `main` and folder `/(root)`, then save.
6. Visit `https://YOUR-USERNAME.github.io`.

## Important limitations
This is a static dashboard preview. It stores entries, settings, snapshots, and activity in the current browser using localStorage. It does not provide real account authentication, shared multi-user storage, a secure API, or a Roblox server connection. Those features require a separately hosted backend. Never put passwords, API keys, database credentials, or private tokens in this repository.

The module manager stores references to trusted ModuleScripts that are already included in your Roblox experience. It does not download or execute arbitrary Lua code.
